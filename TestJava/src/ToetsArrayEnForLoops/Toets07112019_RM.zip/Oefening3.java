package ToetsArrayEnForLoops;

public class Oefening3 {
	public static void main(String args[]) {
		
		Oefening3 getallen = new Oefening3();
		getallen.EvenNumbers();
		
		public void EvenNumbers() {
			for (int i = -20; i < -50; i++) {
				System.out.println(i);
			}
		}
		
	}
}
