package ToetsArrayEnForLoops;

public class Oefening2 {
	public static void main(String args[]) {
		
	}
}
