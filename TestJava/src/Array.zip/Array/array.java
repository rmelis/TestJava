package Array;

public class array {
	public static void main(String[] args) {
		array array  = new array();
		//instantie "array" aanmaken van klasse "array"
		array.loop1To10();
		//methode uitvoeren op de instantie "array"
		
		//array string = new array();
		//instantie "string" aanmaken van klasse "array"
		String tekst = "tekst";
		System.out.println(tekst);
		
	}
	
	public void loop1To10() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
		
	}
	
	public void omgedraaideString() {
		
	}
	
}
