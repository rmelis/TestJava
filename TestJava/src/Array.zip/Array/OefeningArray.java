package Array;

public class OefeningArray {
	public static void main(String args []) {
		OefeningArray array = new OefeningArray();
		String omgedraaidestring = array.reverseString("Dit is een zin");
		System.out.println(omgedraaidestring);
		omgedraaidestring = array.reverseString("dkjsgog");
		System.out.println(omgedraaidestring);
	}
	
	public String reverseString(String ditwordtIngevuld) {
		return ditwordtIngevuld;
	}
	
}
