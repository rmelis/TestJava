package Bankrekening;

public class Bank {
	public static void main(String[] args) {
		Bankrekening zichtrekening = new Bankrekening();
		double bedrag = 0.0; 
		System.out.println(bedrag);
		zichtrekening.addMoney(80.0);
	}
	
	
	
}
