package Toets1;

public class Medic {
	public int Hitpoints = 100;

	public void restoreHealth(String Unit, int Hitpoins) {
		Hitpoints = Hitpoints + 15;
		System.out.println("De unit genaamd " + Name + " heeft levens bijgekregen.");
		
		
		
		
	}
}
